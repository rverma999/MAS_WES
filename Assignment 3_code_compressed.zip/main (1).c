#include "cycletime.h"

void initialize_counters(int32_t do_reset, int32_t enable_divider){
    init_counters(do_reset, enable_divider);
}

unsigned int get_cycle_count(void){
    return get_cyclecount();
}
